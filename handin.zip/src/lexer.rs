use logos::{Logos, SpannedIter};

use crate::tokens::{LexicalError, Token}; // your Token enum, as above

pub type Spanned<Tok, Loc, Error> = Result<(Loc, Tok, Loc), Error>;

pub struct Lexer<'input> {
    // instead of an iterator over characters, we have a token iterator
    token_stream: SpannedIter<'input, Token>,
}

impl<'input> Lexer<'input> {
    pub fn new(input: &'input str) -> Self {
        // the Token::lexer() method is provided by the Logos trait
        Self {
            token_stream: Token::lexer(input).spanned(),
        }
    }
}

impl Iterator for Lexer<'_> {
    type Item = Spanned<Token, usize, LexicalError>;

    fn next(&mut self) -> Option<Self::Item> {
        self.token_stream
            .next()
            .map(|(token, span)| match token.clone() {
                Ok(t) => Ok((span.start, t, span.end)),
                Err(err) => {
                    let problematic_text = self.token_stream.source()[span.clone()].to_string();
                    println!(
                        "lexer error: {:?} {:?} {:?}. Problematic: {}",
                        err, token, span, problematic_text
                    );
                    Err(err)
                }
            })
    }
}
